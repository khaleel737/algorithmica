---
title: Actor Model
weight: 4
---
