---
title: Arithmetic Optimizations
weight: 10
draft: true
---

...
