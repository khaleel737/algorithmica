---
title: Дерево отрезков на массиве
weight: 2
draft: true
---


![](http://i.imgur.com/GGBmcEP.png)
