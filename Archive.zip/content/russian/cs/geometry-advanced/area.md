---
title: Нахождение площадей
draft: true
---
