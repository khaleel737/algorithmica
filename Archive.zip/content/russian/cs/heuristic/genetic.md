---
title: Генетические алгоритмы
draft: true
---