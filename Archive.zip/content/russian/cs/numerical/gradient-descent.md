---
title: Градиентный спуск
draft: true
---
