---
title: Алгоритмы
menuTitle: CS
weight: 1
hideSidebar: true
---

В этот раздел с течением времени будут переноситься статьи с [алгокода](http://wiki.algocode.ru/), [емакса](http://e-maxx.ru/algo/) и [старой алгоритмики](https://algorithmica.org/ru/).
