---
title: Динамика по подмножествам
weight: 13
draft: true
---

