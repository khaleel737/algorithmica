---
title: Замена ответа на параметр
draft: true
---