---
title: Построение графиков (Matplotlib)
---
