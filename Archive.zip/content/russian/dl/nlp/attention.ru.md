---
title: Механизм Attention
---
